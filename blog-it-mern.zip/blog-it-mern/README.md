# Blog It - MERN Stack Blog App

This is a full-stack blog application built using the MERN stack.