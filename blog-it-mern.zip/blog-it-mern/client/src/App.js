import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import FeaturedPosts from './components/FeaturedPosts';
import UserBlogs from './components/UserBlogs';
import Recommendations from './components/Recommendations';
import AddPostForm from './components/AddPostForm';
import Comments from './components/Comments';
import Footer from './components/Footer';
import ChatBox from './components/ChatBox';

function App() {
  return (
    <div>
      <Header />
      <Hero />
      <FeaturedPosts />
      <UserBlogs />
      <Recommendations />
      <AddPostForm />
      <Comments />
      <Footer />
      <ChatBox />
    </div>
  );
}

export default App;