import React from 'react';
const AddPostForm = () => <section><h2>Add a New Post</h2></section>;
export default AddPostForm;