import React from 'react';
const ChatBox = () => <section><h2>Chat with Us</h2></section>;
export default ChatBox;