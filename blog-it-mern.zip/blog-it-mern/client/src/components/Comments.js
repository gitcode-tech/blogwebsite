import React from 'react';
const Comments = () => <section><h2>Comments</h2></section>;
export default Comments;