import React from 'react';
const FeaturedPosts = () => <section><h2>Featured Posts</h2></section>;
export default FeaturedPosts;