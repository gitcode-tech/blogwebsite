import React from 'react';
const Footer = () => <footer><p>&copy; 2025 Blog It</p></footer>;
export default Footer;