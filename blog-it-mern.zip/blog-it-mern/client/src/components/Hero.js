import React from 'react';
const Hero = () => <section className='hero'><h2>Welcome to Blog It</h2></section>;
export default Hero;