import React from 'react';
const Recommendations = () => <section><h2>Recommendations</h2></section>;
export default Recommendations;