import React from 'react';
const UserBlogs = () => <section><h2>User Blogs</h2></section>;
export default UserBlogs;